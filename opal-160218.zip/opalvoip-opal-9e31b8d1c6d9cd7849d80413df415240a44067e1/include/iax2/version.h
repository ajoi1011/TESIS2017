/*
 *
 * Inter Asterisk Exchange 2
 * 
 * Version number header file for the IAX2 library implementation
 * 
 * Open Phone Abstraction Library (OPAL)
 *
 * Copyright (c) 2005 Indranet Technologies Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open Phone Abstraction Library.
 *
 * The Initial Developer of the Original Code is Indranet Technologies Ltd.
 *
 * The author of this code is Derek J Smithies
 */

#ifndef _IAX2_VERSION_H
#define _IAX2_VERSION_H

#define MAJOR_VERSION 0
#define MINOR_VERSION 1
#define BUILD_TYPE    AlphaCode
#define BUILD_NUMBER 1


#endif  // _IAX2_VERSION_H


// End of File ///////////////////////////////////////////////////////////////
