/*
 * sip.h
 *
 * Session Initiation Protocol support.
 *
 * Open Phone Abstraction Library (OPAL)
 * Formally known as the Open H323 project.
 *
 * Copyright (c) 2001 Equivalence Pty. Ltd.
 *
 * The contents of this file are subject to the Mozilla Public License
 * Version 1.0 (the "License"); you may not use this file except in
 * compliance with the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS"
 * basis, WITHOUT WARRANTY OF ANY KIND, either express or implied. See
 * the License for the specific language governing rights and limitations
 * under the License.
 *
 * The Original Code is Open Phone Abstraction Library.
 *
 * The Initial Developer of the Original Code is Equivalence Pty. Ltd.
 *
 * Contributor(s): ______________________________________.
 */

#ifndef OPAL_SIP_SIP_H
#define OPAL_SIP_SIP_H

#include <opal_config.h>

#if OPAL_SIP

#include <sip/sipep.h>
#include <sip/sipcon.h>


#endif // OPAL_SIP

#endif // OPAL_SIP_SIP_H


// End of File ///////////////////////////////////////////////////////////////
