/*
 * precompile.cxx
 *
 * PWLib application source file for PxmlTest
 *
 * Precompiled header generation file.
 *
 * Copyright 2002 David Iodice.
 *
 */

#include <ptlib.h>


// End of File ///////////////////////////////////////////////////////////////
