/*
 * syncpoint.h
 *
 * Thread synchronisation point (event) class.
 *
 * Portable Windows Library
 *
 * Copyright (c) 1993-1998 Equivalence Pty. Ltd.
 *
 * Copyright (c) 1999 ISDN Communications Ltd
 *
 */


#ifndef _PSYNCPOINT


///////////////////////////////////////////////////////////////////////////////
// PSyncPoint

#include "../../syncpoint.h"
};


#endif
