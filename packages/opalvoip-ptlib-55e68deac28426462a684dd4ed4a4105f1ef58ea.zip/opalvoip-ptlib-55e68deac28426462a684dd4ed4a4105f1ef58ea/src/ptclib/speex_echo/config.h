#include <ptlib.h>
#define inline __inline
#define restrict
#include "misc.h"