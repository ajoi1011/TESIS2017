/*
 * precompile.cxx
 *
 * PWLib application source file for XMPPTest
 *
 * Precompiled header generation file.
 *
 * Copyright 2004 Reitek S.p.A.
 *
 */

#include "main.h"


// End of File ///////////////////////////////////////////////////////////////
