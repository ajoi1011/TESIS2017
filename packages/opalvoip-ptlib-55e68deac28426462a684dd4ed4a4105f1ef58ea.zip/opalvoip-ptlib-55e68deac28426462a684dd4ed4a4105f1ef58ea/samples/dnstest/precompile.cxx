/*
 * precompile.cxx
 *
 * PWLib application source file for dnssrv
 *
 * Precompiled header generation file.
 *
 * Copyright 2003 Equivalence
 *
 */

#include <ptlib.h>
#include <ptlib/pprocess.h>


// End of File ///////////////////////////////////////////////////////////////
