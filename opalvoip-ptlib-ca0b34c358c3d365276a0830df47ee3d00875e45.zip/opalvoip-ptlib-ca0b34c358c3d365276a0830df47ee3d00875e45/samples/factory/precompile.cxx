/*
 * precompile.cxx
 *
 * PWLib application source file for dnssrv
 *
 * Precompiled header generation file.
 *
 * Copyright 2003 Equivalence
 *
 */

#include "abstract.h"


// End of File ///////////////////////////////////////////////////////////////
