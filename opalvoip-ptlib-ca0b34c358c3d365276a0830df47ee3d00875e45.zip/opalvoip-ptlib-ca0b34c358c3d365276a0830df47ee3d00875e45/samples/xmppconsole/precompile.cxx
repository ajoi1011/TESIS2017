/*
 * precompile.cxx
 *
 * PWLib application source file for XMPPConsole
 *
 * Originally from the XMPPTest module, copied here by Derek Smithies.
 *
 * Precompiled header generation file.
 *
 * Copyright 2004 Reitek S.p.A.
 *
 */

#include <ptlib.h>


// End of File ///////////////////////////////////////////////////////////////
