The following files were removed in order to be compatible with
the Debian distribution guidelines


   draft-ietf-xmpp-core-22.txt
   draft-ietf-xmpp-im-21.txt

I'm not going to even try and understand why, but seeing as these
files are old versions of documents available in many places on the
Internet, I see no reason to make an issue of this.

The following link is for those perverse individuals who want to try 
and understand what this is all about.

http://bugs.debian.org/cgi-bin/bugreport.cgi?bug=365176

   Craig Southeren, 30 April 2006